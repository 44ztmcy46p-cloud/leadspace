# Runda r28 — Doprecyzowanie opcjonalności oferty i usunięcie orientacyjnej daty

## Bazuje na
r27 — leadspace-public-r27.zip oraz Leadspace-pelna-strona-offline-r27.zip.

## Zmiany
### pages/nieruchomosci.html
- W obu wariantach sprzedaży (budynki i lokale oraz działki) oznaczono oczekiwany rodzaj oferty jako opcjonalny.
- Usunięto pole orientacyjnej daty skorzystania z usługi z obu wariantów sprzedaży. Pozostawiono „Termin skorzystania z usługi”.
- Sprawdzono wszystkie dziewięć podstron: na pozostałych podstronach usuwane pole już nie występuje.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Nieruchomości / Sprzedaż / Budynki i lokale: „Oczekiwany rodzaj oferty” → „Oczekiwany rodzaj oferty (opcjonalne)”.
- Nieruchomości / Sprzedaż / Działki: „Oczekiwany rodzaj oferty” → „Oczekiwany rodzaj oferty (opcjonalne)”.
- Nieruchomości / Sprzedaż / Oba warianty: usunięto „Orientacyjna data skorzystania z usługi”.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Pakiet wdrożeniowy jest poprawką na r27: zawiera pełny zmieniony plik pages/nieruchomosci.html i ten opis. Nie zawiera skryptu podglądu ani plików generowanych.
- Paczka offline zawiera całą stronę i nie wymaga wcześniejszych wersji.
