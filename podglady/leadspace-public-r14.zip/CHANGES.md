# Runda r14 — Finalne poprawki hero, podglądu sklepu i opisów strony głównej

## Bazuje na
leadspace-public-r13.zip i zrzut aktualnego sklepu przesłany przez użytkownika.

## Zmiany
### pages/index.html
- Nowy H1 i CTA rejestracji w hero.
- Aktualna dostępność zamiast przykładowej; liczniki zastąpiono „—”, zgodnie z odpowiedzią użytkownika, że dane przygotuje programista. Nie przedstawiono przykładowych wartości jako aktualnych.
- Usunięto widoczną notę koncepcji i przyszłego licznika oraz dopiski Dane demonstracyjne przy kartach branż. ID home-availability-note zachowano jako sr-only z krótkim opisem dostępności.
- Odtworzono sklep ze zrzutu jako semantyczny HTML: LS · Lead Space, pasek kategorii, panel klienta, katalog, filtry, region i cena, pięć przykładowych wierszy. Nie jest to działający sklep. Zrzut z danymi przykładowymi nie zasila liczników dostępności.
- Zachowano stare ID podglądu i tabeli, aria i region przewijania. Usunięto ze środka podglądu dawne moduły CRM, kalendarz, nagrania, raporty. Mockup nie zawiera danych osobowych ani działających operacji zakupowych.
- Dodano podpisy etapów 01 i 02 oraz zmieniono opis pakietów.
- Sekcje Jak rozpocząć współpracę i końcowy Kontakt pozostają identyczne z r13.
### css/additions.css
- Dodano scoped store-* do odtworzonego katalogu, zaokrąglenie 20 px i więcej odstępu po hero (90 px desktop, 58 px telefon).
- Podgląd tabeli przewija się we własnym kontenerze na telefonie; tekst i tabela pozostają HTML, nie obrazem.
- Dodano etykiety porównania pochodzenia leadów.

## Nowe klasy CSS
- store-preview, store-app, store-toolbar, store-brand, store-logo, store-token, store-navigation, store-wallet, store-basket, store-layout, store-sidebar, store-sidebar-active, store-sidebar-label, store-sidebar-tip, store-content, store-screen-heading, store-guide, store-filters, store-sort, store-table-viewport, store-table-tools, store-table, store-lead-heading, store-price, store-checkbox, store-add — podgląd sklepu.
- home-process-origin, home-process-origin-brand — podpisy pod etapami 01 i 02.
- Wszystkie w css/additions.css.

## Usunięte / nieużywane klasy
- Dawne app-* w podglądzie oraz v3-browserbar nieużywane w tym nowym komponencie; ich CSS nie usunięto.

## Nowe tokeny kolorów
- --color-pub-preview-line: #ebe9e3 — obramowania katalogu.
- --color-pub-preview-warm: #fff3dd — status Ciepły.
- --color-pub-preview-action: #eef0ff — ilustracyjna akcja Dodaj.

## Zmiany tekstów
- „Kontakt to dopiero początek. Rozmawiaj, wiedząc więcej.” → „Lead to dopiero początek. Pracuj na zweryfikowanych leadach.”
- Hero CTA „Porozmawiajmy o współpracy” → „Zarejestruj się”, href /accounts/signup/.
- „Przykładowa dostępność w sklepie” → „Aktualna dostępność w sklepie”.
- „Przykładowa dostępność” → „Aktualna dostępność” na kartach branż.
- Usunięto „Podgląd koncepcji · liczby demonstracyjne, nie są aktualnym stanem sklepu.”, „Dane demonstracyjne” i „Docelowo licznik będzie pokazywał leady dostępne do zakupu, bez sprzedanych i zarezerwowanych.”
- 286, 128, 96, 62 → placeholder „—”, aria-label informuje, że aktualna liczba nie jest jeszcze dostępna.
- Etap 01 dodano „Inne leady dostępne na rynku”. Etap 02 dodano „Leady LeadSpace”.
- Opis pakietów → „Doładuj konto dowolną kwotą i zacznij kupować nawet pojedyncze kontakty. Możesz też wybrać jeden z pakietów, otrzymując dodatkowe środki na zakup leadów.”
- Podgląd sklepu odtwarza widoczne na zrzucie etykiety: Lead Space, Nieruchomości, Panel klienta, Moje leady, Ulubione, Zapotrzebowanie, Reklamacje, Portfel 800,00 zł, Koszyk 0, Wszystkie leady, kategorie nieruchomości, filtry, LEAD / REGION / CENA / AKCJA, pięć pozycji LS-408, LS-409, LS-410, LS-396, LS-411 z ceną 120 zł. Zastępuje dawną tabelę imion, branż i statusów.
- Podpis pod podglądem: „Widok katalogu leadów w sklepie LeadSpace”.

## Nowe ikony (Lucide) i obrazy
brak — logo ze zrzutu odwzorowano tekstem LS i Lead Space w HTML/CSS, bez zewnętrznych zasobów.

## Do decyzji / pytania
- Użytkownik potwierdził, że programista przygotuje aktualne liczniki. Placeholdery podłączyć do danych aplikacji, nie do przykładowych wartości z podglądu.
- Rejestracja nadal wskazuje /accounts/signup/; rzeczywistą trasę potwierdzić w Django.
- Kontrolki podglądu sklepu są wyłącznie ilustracyjne; nie realizują filtrowania, zakupu ani zarządzania portfelem.
- Chromium 390, 768, 1440 px: jeden H1, rejestracja, pięć wierszy katalogu, podpisy procesu, placeholdery, linki kotwic, działający dialog kontaktowy, brak błędów JS i brak poziomego scrolla całej strony.
- Sprawdzono zachowanie wszystkich poprzednich ID i identyczność sekcji startu współpracy oraz końcowego kontaktu.
