# Runda r04 — Wyrównanie kart i kontakt przez formularz

## Bazuje na
leadspace-public-r03.zip

## Zmiany
### pages/cennik.html
- Nagłówek pierwszej karty to większe „Dowolna kwota”, bez dopisku netto.
- Zastąpiono dolny kontakt układem sekcji kontaktowej ze strony głównej aktualnego eksportu: centralny nagłówek, opis i przycisk Kontakt otwierający istniejący dialog public-contact#open.
- Usunięto e-mail wyłącznie z tej sekcji. Wspólna stopka pozostaje bez zmian.
### css/additions.css
- Wspólne wysokości wierszy kart przez subgrid. Wiersze doładowania i bonusu mają dopasowane wysokości, aby kreski były w tych samych miejscach w każdym rzędzie kart.
- Zwiększono tekst Dowolna kwota do skali kwot pozostałych kart.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
- packages-contact, packages-contact-row nie są używane w nowej sekcji. Reguł nie usunięto.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- „Dowolna kwota netto” w głównym nagłówku karty → „Dowolna kwota”. Dopiski netto w zestawieniu zachowano.
- Dolna sekcja: „Masz pytania? Porozmawiajmy o Twoich potrzebach.” → „Zróbmy pierwszy krok. Ty znasz swoją ofertę. My pomożemy znaleźć odbiorców.”
- Opis: „Porozmawiajmy o tym, jak LeadSpace może wesprzeć Twoją sprzedaż.”
- Przycisk „Porozmawiajmy o współpracy” → „Kontakt”.
- Usunięto adres e-mail z sekcji kontaktowej.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- 390, 768, 1440 px: brak poziomego scrolla; zmierzono wyrównanie wszystkich separatorów w kartach należących do tego samego rzędu; Kontakt otwiera formularz, zamknięcie działa.
- Subgrid wymaga współczesnej przeglądarki (Chrome 117+, Firefox 71+, Safari 16+).
- Rejestracja pozostaje /accounts/signup/ zgodnie z poprzednimi rundami; backend nie był testowany.
