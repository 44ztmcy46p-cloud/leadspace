# Runda r10 — Nowy układ strony głównej i start współpracy w sklepie

## Bazuje na
leadspace-public-r09.zip

## Zmiany
### pages/index.html
- Kolejność sekcji: v3-home (Kontakt to dopiero początek), v3-how (proces), v3-industries (bez zmian treści), v3-start (nowy start), v3-contact (sekcja jak w Pakietach).
- Hero ma H1; proces zmieniony na H2 dla jednej głównej hierarchii.
- Na wyraźne polecenie użytkownika usunięto v3-value i v3-features wraz z zawartością, w tym starymi obietnicami CRM. Nie pozostawiono linków do usuniętych bloków.
- Zachowano ID v3-step-1..3; przyciski spotkania zastąpiono linkami Zarejestruj się wskazującymi /accounts/signup/.
- Skopiowano dokładnie końcową sekcję z Pakietów; technicznie ID dopasowano do v3-contact oraz v3-contact-title, formularz nadal otwierany przez public-contact#open.
- Nagłówek, head, APP comments, stopka, formularz i podgląd platformy zachowane. Liczby leadów niezmienione.
### css/additions.css
- Dotychczasowe reguły sekcji końcowej Pakietów rozszerzono na v3-contact przez :is(), aby wygląd obu sekcji był identyczny.
- Zachowano skalę tytułu procesu po zmianie H1 na H2.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
- v3-value-list i concept-faq nieużywane w usuniętych blokach strony głównej; reguły pozostawiono dla innych stron.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Krok 01: Skontaktuj się → Zarejestruj się. „Utwórz konto i poznaj leady dostępne dla Twojej branży.” / „Wybierz kontakty, które pasują do Twojej oferty.”
- Krok 02: Rozpocznij współpracę → Doładuj konto lub kup pakiet. „Zacznij od dowolnej kwoty albo wybierz pakiet z dodatkowym bonusem.” / „Ty decydujesz, ile środków przeznaczysz na zakup leadów.”
- Krok 03: Pozyskuj klientów → Kupuj leady. „Wybierz interesujące kontakty, kup je i pobierz dane.” / „Przygotuj ofertę i rozpocznij rozmowę z potencjalnym klientem.”
- CTA trzech kroków: Umów spotkanie → Zarejestruj się.
- Końcowa sekcja zastąpiona treścią z Pakietów: „WIĘCEJ NIŻ KONTAKT Z REKLAMY”, „Najpierw weryfikacja. Potem Twój kolejny krok.” i dwa akapity o ankiecie i kontroli jakości. CTA: Kontakt.
- Usunięto w całości treści Przygotuj się. Porozmawiaj. Pozyskaj klienta oraz Dobry kontakt to dopiero początek, zgodnie z poleceniem.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768, 1440 px: poprawna kolejność pięciu sekcji, jeden H1, brak poziomego przewijania, poprawne kotwice, trzy CTA rejestracji, działający dialog kontaktowy, brak błędów JS.
- Rejestracja /accounts/signup/ pozostaje trasą roboczą z poprzednich rund; backend nie był testowany.
- Statyczny podgląd platformy i jego dane pozostawiono zgodnie z zakresem tej rundy.
