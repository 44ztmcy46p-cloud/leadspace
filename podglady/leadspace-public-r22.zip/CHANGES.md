# Runda r22 — Kontakt w obecnej stylistyce Leadspace

## Bazuje na
leadspace-public-r21.zip

## Zmiany
### pages/kontakt.html
- Zastąpiono układ dokumentu otwarciem z dużą typografią, dwiema kolumnami, kartą operatora i panelem formularza.
- Zachowano wszystkie dane operatora, pola formularza, ID, name, type, required, role, aria, data-contact-form-* oraz wiadomości błędów i sukcesu.
- Telefon jest teraz klikalnym linkiem tel:+48664005036.
- Przy submit dodano concept-button, zachowując dotychczasowe klasy i kontrakt aplikacji.
- Górny CTA dopasowano do aktualnej strony głównej i O nas: Zarejestruj się z /accounts/signup/.
- Dane i treści prawne zgody pozostały bez zmian. Stopka, head i wspólny dialog pozostają identyczne.
### css/additions.css
- Dodano scoped contact-* z kremowym tłem, pastelowym otwarciem, błękitną kartą operatora i formularzem.
- Pola podstawowe w dwóch kolumnach na desktopie, jednej na mniejszych ekranach. Opcje tematów mają czytelne stany wybrane.
- Zachowano jeden czarny styl CTA i widoczny fokus klawiaturowy.

## Nowe klasy CSS
- contact-hero, contact-content, contact-layout, contact-information, contact-information-intro, contact-operator, contact-topics, contact-form-panel, contact-form-intro, contact-submit (css/additions.css).

## Usunięte / nieużywane klasy
- ls-section, ls-legal, ls-eyebrow, ls-h nie są już używane w main tej strony; reguły zachowano dla innych stron.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Nagłówek: Napisz do nas → Porozmawiajmy o Twoich potrzebach.
- Wprowadzenie: „Masz pytania dotyczące dostępnych leadów, działania platformy lub współpracy z Leadspace? Napisz do nas. Pomożemy Ci poznać ofertę i rozpocząć korzystanie ze sklepu.”
- Dodano „JESTEŚMY DO TWOJEJ DYSPOZYCJI”, „Wybierz wygodny sposób kontaktu.” i opis formularza, e-maila i telefonu.
- Dodano tematy pomocy: dostępne leady i zakres danych, korzystanie ze sklepu, doładowania/pakiety/płatności, współpraca.
- Dodano „NAPISZ DO NAS” oraz „Wybierz temat i zostaw wiadomość. Pola oznaczone * są obowiązkowe.”
- Dekoracyjne emoji operatora zastąpiono monogramem DGM.
- Górny CTA Umów spotkanie → Zarejestruj się.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768 i 1440 px: jeden H1, brak poziomego scrolla, link telefonu, sześć tematów, wypełnianie pól oraz natywna walidacja obowiązkowych pól, brak błędów JS.
- Porównanie parserem potwierdziło zachowanie wszystkich atrybutów i kolejności kontrolek, targetów, ukrytych błędów i sukcesu (poza dodaniem klas CSS do submit).
- Wysyłka wiadomości ani backend nie były testowane. Formularz wymaga sprawdzenia w aplikacji Django.
- Trasa rejestracji /accounts/signup/ pozostaje jak w poprzednich rundach.
