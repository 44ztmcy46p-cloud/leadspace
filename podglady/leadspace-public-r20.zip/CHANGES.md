# Runda r20 — Rejestracja na stronie O nas

## Bazuje na
leadspace-public-r19.zip

## Zmiany
### pages/o-nas.html
- W nagłówku link Zarejestruj się zamiast przycisku spotkania.
- W otwarciu link Zarejestruj się zamiast kotwicy do kontaktu.
- Dolny kontakt zastąpiono mini sekcją rejestracji. Zachowano ID about-contact i about-contact-title.
- Sekcje misji, oferty i odbiorców bez zmian, potwierdzone porównaniem źródła.
- Wszystkie trzy CTA wskazują /accounts/signup/ i używają istniejącego concept-button.
### css/additions.css
- Dodano kompaktową sekcję rejestracji z różowym tłem, poziomym układem desktop i pionowym mobilnym.

## Nowe klasy CSS
- about-register, about-register-row (css/additions.css).

## Usunięte / nieużywane klasy
- about-contact, about-contact-grid, about-contact-card, about-email, about-contact-link nieużywane w nowej dolnej sekcji; CSS zachowano.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Nagłówek: Umów spotkanie → Zarejestruj się.
- Otwarcie: Porozmawiajmy o współpracy → Zarejestruj się.
- Usunięto dawną dolną sekcję kontaktu, adres e-mail i link do strony kontaktowej z tej sekcji.
- Nowa mini sekcja: „TWÓJ KOLEJNY KROK”, „Zacznij od konta w LeadSpace.”, „Zarejestruj się i uzyskaj dostęp do sklepu z weryfikowanymi leadami.”, CTA „Zarejestruj się”.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768 i 1440 px: trzy linki rejestracji, jeden H1, brak poziomego przewijania i usunięty blok kontaktowy.
- Trasa /accounts/signup/ jak w poprzednich rundach; backend rejestracji nie był testowany.
