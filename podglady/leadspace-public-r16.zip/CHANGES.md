# Runda r16 — Rejestracja w nagłówku, prostszy hero i oznaczenie etapu jakości

## Bazuje na
leadspace-public-r15.zip

## Zmiany
### pages/index.html
- Górny przycisk spotkania zastąpiono linkiem rejestracji w identycznym stylu concept-button.
- Skrócono H1 do jednego zdania.
- Usunięto osobne różowe prostokąty pod kartami procesu. Zachowano cztery etapy; dyskretny podpis Leady Lead Space znajduje się wewnątrz etapu 03.
- Zmieniono opis pierwszego kroku rozpoczęcia współpracy.
- Branże i końcowy kontakt pozostawiono identyczne z r15.
### css/additions.css
- Powiększono podgląd katalogu do maksymalnie 1100 px (poprzednio 960 px).
- Dodano mały podpis etapu jakości, bez nowego prostokąta.

## Nowe klasy CSS
- home-process-quality-label — podpis w etapie 03 (css/additions.css).

## Usunięte / nieużywane klasy
- home-process-item, home-process-label nie są już używane na stronie; CSS zachowano.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Górny CTA: Umów spotkanie → Zarejestruj się, href /accounts/signup/.
- H1: Lead to dopiero początek. Tylko sprawdzone kontakty. → Lead to dopiero początek.
- Usunięto podpis Inne leady dostępne na rynku.
- Leady Lead Space przeniesiono do etapu 03 Kontrola jakości.
- Opis kroku 01: Utwórz konto i poznaj leady dostępne dla Twojej branży. → Utwórz konto i uzyskaj dostęp do sklepu.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Wybrano dopuszczoną przez użytkownika alternatywę: zostawiono proces, ale usunięto różowe prostokąty i umieszczono podpis w 03.
- Chromium 390, 768 i 1440 px: link rejestracji, H1, podpis w 03, opis startu, kontakt i brak przewijania poziomego. Potwierdzono szerokość katalogu 1100 px na desktopie.
- Trasa rejestracji /accounts/signup/ jak w poprzednich rundach; backend nie był testowany.
