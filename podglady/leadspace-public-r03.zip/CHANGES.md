# Runda r03 — Kwoty netto i brutto w Pakietach

## Bazuje na
leadspace-public-r02.zip

## Zmiany
### pages/cennik.html
- Dopisano netto przy kwotach doładowania oraz przy środkach do wykorzystania.
- Pod kwotami doładowania podano mniejszym tekstem kwoty brutto: 3 075 zł, 6 150 zł, 12 300 zł. Kwoty są zgodne z VAT 23%.
- Dodatkowy bonus pokazuje wyłącznie kwotę netto. Procent pozostaje w etykiecie pakietu i w banerze.
- Dowolne doładowanie opisano jako kwotę netto, z informacją o doliczeniu VAT do kwoty brutto.
- Bez zmiany tras rejestracji, formularza, ID, nazw i atrybutów aplikacji.
### css/additions.css
- Dodano mniejszy dopisek jednostki netto oraz mniejsze kwoty brutto pod kwotami doładowania.

## Nowe klasy CSS
- packages-unit — dopisek netto przy dużej kwocie.
- packages-gross — kwota brutto pod głównym doładowaniem.
- packages-gross-inline — kwota brutto pod doładowaniem w zestawieniu.
- Wszystkie w css/additions.css.

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Dowolna kwota → Dowolna kwota netto. Dodano: „Kwota brutto: netto + 23% VAT”.
- Twoja wpłata → Twoja wpłata netto.
- 2 500 zł → 2 500 zł netto; pod spodem 3 075 zł brutto.
- 5 000 zł → 5 000 zł netto; pod spodem 6 150 zł brutto.
- 10 000 zł → 10 000 zł netto; pod spodem 12 300 zł brutto.
- Bonus 125 zł · +5% → 125 zł netto.
- Bonus 350 zł · +7% → 350 zł netto.
- Bonus 1 000 zł · +10% → 1 000 zł netto.
- Do wykorzystania: 2 625 zł → 2 625 zł netto; 5 350 zł → 5 350 zł netto; 11 000 zł → 11 000 zł netto.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Rejestracja nadal wskazuje /accounts/signup/ zgodnie z r02, trasa wymaga potwierdzenia w backendzie.
- Chromium 390, 768, 1440 px: poprawne kwoty i dopiski, brak procentów w wierszach bonusów, brak poziomego przewijania. Sprawdzono rachunki VAT i sumy netto.
