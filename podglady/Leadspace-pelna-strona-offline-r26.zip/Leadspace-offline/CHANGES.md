# Runda r26 — Usunięcie bloku Korzystanie z danych z Pakietów

## Bazuje na
Pełna wersja offline r25.

## Zmiany
### pages/cennik.html
- Usunięto wyłącznie sekcję packages-use z pytaniem o okres wykorzystania leada.
- Pozostałe sekcje i dokumenty prawne bez zmian.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Usunięto „KORZYSTANIE Z DANYCH”, „Jak długo mogę korzystać z leada?” i akapit o standardowym okresie 30 dni.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
brak
