# Runda r05 — Przywrócenie treści i koloru kontaktu

## Bazuje na
leadspace-public-r04.zip

## Zmiany
### pages/cennik.html
- Przywrócono poprzedni układ packages-contact i packages-contact-row, z kremowym tłem oraz treścią z r03.
- Zachowano przycisk Kontakt otwierający istniejący formularz; bez adresu e-mail w tej sekcji.
- Pozostałe sekcje i CSS bez zmian.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Przywrócono „MASZ PYTANIA?”, „Porozmawiajmy o Twoich potrzebach.” oraz „Pomożemy Ci poznać dostępne leady i możliwości współpracy.”
- Przycisk nadal „Kontakt”.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390 i 1440 px: poprawna treść, brak poziomego przewijania, formularz otwiera się i zamyka.
