# Runda r19 — Usunięcie podpisów z kart procesu

## Bazuje na
leadspace-public-r18.zip

## Zmiany
### pages/index.html
- Usunięto podpisy z kart 01 i 03. Proces pozostaje czterema równymi kartami.
- Górny przycisk Zarejestruj się potwierdzony, był już poprawiony w r16.
- Wszystkie pozostałe sekcje i CSS bez zmian.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
- home-process-footer-label, home-process-market-label nie są już używane; CSS zachowano.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Usunięto Leady dostępne na rynku i Leady Leadspace.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390 i 1440 px: cztery karty bez podpisów, rejestracja w nagłówku, brak poziomego przewijania.
