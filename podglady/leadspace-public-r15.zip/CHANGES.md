# Runda r15 — Krótszy hero, osobne etykiety procesu i usunięcie Pakietów z homepage

## Bazuje na
leadspace-public-r14.zip

## Zmiany
### pages/index.html
- Zmieniono drugi wiersz H1.
- Etykiety porównania przeniesiono z wnętrza kart 01 i 02 do osobnych różowych prostokątów poniżej kart.
- Zmieniono opis dostępności na leadów w sklepie. Aktualna dostępność i brak not demonstracyjnych zachowane z r14.
- Usunięto sekcję home-packages zgodnie z poleceniem. Podstrona Pakiety i linki menu pozostają.
- Sekcje rozpoczęcia współpracy i końcowego kontaktu pozostały dokładnie bez zmian.
### css/additions.css
- Podgląd katalogu zmniejszono do maksymalnie 960 px i samej sekcji wewnętrznej: ukryto toolbar i boczne menu, wyświetlane są trzy pierwsze wiersze. Pozostałe ID i wiersze zostają w źródle.
- Dodano osobne etykiety procesu i wyrównano wysokości kart.

## Nowe klasy CSS
- home-process-item — karta z podpisem pod nią.
- home-process-label — osobny różowy prostokąt.
- Obie w css/additions.css.

## Usunięte / nieużywane klasy
- home-process-origin, home-process-origin-brand nie są już używane w HTML; ich CSS zachowano.
- Klasy home-packages i home-package-* nie są używane na homepage po usunięciu sekcji; reguł nie usunięto.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- „Lead to dopiero początek. Pracuj na zweryfikowanych leadach.” → „Lead to dopiero początek. Tylko sprawdzone kontakty.”
- „leadów do kupienia” → „leadów w sklepie” na kartach branż.
- Podpisy „Inne leady dostępne na rynku” i „Leady LeadSpace” zachowano, zmieniając ich położenie.
- Cała sekcja „Doładuj konto. Skorzystaj z bonusu.” została usunięta ze strony głównej.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768 i 1440 px: H1, trzy widoczne wiersze podglądu, osobne podpisy, brak sekcji pakietów, kontakt i brak poziomego przewijania.
- Potwierdzono identyczność v3-start i v3-contact ze stanem r14.
- Liczniki nadal placeholder „—” do podłączenia przez programistę. Podgląd sklepu jest ilustracyjny.
