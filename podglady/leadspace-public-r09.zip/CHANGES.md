# Runda r09 — Przycisk rejestracji w sekcji rozpoczęcia

## Bazuje na
leadspace-public-r08.zip

## Zmiany
### pages/cennik.html
- W pierwszym kroku sekcji packages-how dodano link Zarejestruj się w istniejącym stylu concept-button, wskazujący /accounts/signup/.
### css/additions.css
- Dodano odstęp ponad przyciskiem rejestracji.

## Nowe klasy CSS
- packages-register — margin-top 22px (css/additions.css).

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- „Kliknij «Wybierz» i utwórz konto w LeadSpace.” → „Kliknij «Zarejestruj się» i utwórz konto w LeadSpace.”

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390 i 1440 px: poprawny opis, link rejestracji i brak poziomego przewijania.
- Trasa /accounts/signup/ pozostaje robocza jak w poprzednich rundach; backend rejestracji nie był testowany.
