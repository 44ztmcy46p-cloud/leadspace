# Runda r17 — Wyrównanie hero i kart procesu

## Bazuje na
leadspace-public-r16.zip

## Zmiany
### pages/index.html
- Usunięto podpis nad tytułem etapu 03. Dodano podpisy na dole kart: 01 Leady dostępne na rynku, 03 Leady Leadspace.
- Górny CTA Zarejestruj się zachowany z r16.
### css/additions.css
- Poszerzono opis hero do 990 px, aby na desktopie zajmował dwa wiersze.
- Przyciski hero mają jednakową szerokość 260 px; na telefonie wspólną szerokość do 340 px.
- Pasek dostępności ma wspólną maksymalną szerokość 1100 px z podglądem sklepu.
- Zwiększono odstęp do podglądu: 64 px desktop, 45 px telefon.
- Równe wysokości kart procesu i podpisy na dole, bez przesuwania nagłówków.

## Nowe klasy CSS
- home-process-footer-label — podpis na dole karty.
- home-process-market-label — różowy podpis w etapie 01.
- Obie w css/additions.css.

## Usunięte / nieużywane klasy
- home-process-quality-label nieużywana po przeniesieniu podpisu; CSS pozostawiono.

## Nowe tokeny kolorów
- --color-pub-market-label: #9b386e — czytelny różowy podpis etapu 01.

## Zmiany tekstów
- Leady Lead Space → Leady Leadspace.
- Dodano Leady dostępne na rynku w etapie 01.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768 i 1440 px: brak scrolla poziomego, równe szerokości przycisków i paska/podglądu, równe wysokości kart oraz właściwe podpisy. Przy 1440 px opis hero zajmuje dwa wiersze.
