# Runda r08 — Dowolna kwota w jednym wierszu

## Bazuje na
leadspace-public-r07.zip

## Zmiany
### css/additions.css
- packages-flexible: font-size 30px i white-space nowrap. Pierwsza kwota mieści się w jednym wierszu, przez co wspólny wiersz cen staje się niższy i kwoty brutto są bliżej cen netto.
- Zachowano wyrównanie kwot brutto i separatorów między kartami.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
brak

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 320, 390, 768, 1440 px: tekst mieści się w jednym wierszu, kwoty brutto i separatory kart tego samego rzędu są wyrównane, brak poziomego przewijania.
