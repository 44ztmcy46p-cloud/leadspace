# Runda r18 — Podział opisu, odstępy i podpisy procesu

## Bazuje na
leadspace-public-r17.zip

## Zmiany
### pages/index.html
- Dodano br przed Ty otrzymujesz, aby drugi wiersz opisu na desktopie zaczynał się od tych słów.
- Treści i trasy pozostałych sekcji bez zmian.
### css/additions.css
- Pasek dostępności odsunięto od przycisków do 60 px (44 px telefon), odstęp do podglądu sklepu zmniejszono do 24 px (22 px telefon).
- Podpisy kart procesu wycentrowano i powiększono do 14 px.
- Link Przejdź do treści ukryty poza fokusem klawiatury; nie pojawia się obok podglądu w normalnym widoku i zrzutach. Dostępność klawiaturowa zachowana.
- Równe szerokości przycisków i górne Zarejestruj się zachowane z r17.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
brak — zmieniono tylko podział wierszy.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768, 1440 px: brak poziomego przewijania, równe przyciski, wyśrodkowane podpisy 14 px, ukryty skip link w normalnym widoku. Desktop: opis zajmuje dwa wiersze z podziałem przed Ty otrzymujesz.
