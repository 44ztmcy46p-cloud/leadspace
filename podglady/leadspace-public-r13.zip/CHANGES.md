# Runda r13 — Przywrócenie wcześniejszej sekcji pakietów

## Bazuje na
r12; przywrócono pages/index.html i css/additions.css dokładnie z r11.

## Zmiany
### pages/index.html
- Cofnięto dodatkową kartę dowolnego doładowania. Ponownie trzy pakiety, informacja o dowolnym doładowaniu w opisie i nagłówek „Doładuj konto. Skorzystaj z bonusu.”.
### css/additions.css
- Przywrócono układ trzech kart z r11.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
- Cofnięto klasy dodane wyłącznie w r12: home-package-flexible, home-package-flexible-note.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Przywrócono pełną treść sekcji z r11.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768 i 1440 px: trzy karty, poprawny link, kolejność sekcji i brak poziomego przewijania.
