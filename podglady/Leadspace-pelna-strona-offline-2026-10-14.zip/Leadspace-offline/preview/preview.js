// PREVIEW ONLY — not part of the delivery, do not edit. On the live site this behaviour comes from the app
// (Stimulus controllers bound by data-controller / data-action / data-*-target attributes). It only makes the
// contact dialog open and close here, so its look can be checked offline.
(() => {
  const body = document.body;
  const dialog = document.querySelector('[data-public-contact-target="dialog"]');
  const category = document.querySelector('[data-public-contact-target="category"]');
  const choices = [...document.querySelectorAll('[data-public-contact-target="choice"]')];
  const notice = document.querySelector('[data-public-contact-target="notice"]');
  const select = (value) => {
    if (category) category.value = value;
    choices.forEach((b) => b.setAttribute('aria-pressed', String(Boolean(value) && b.dataset.publicContactCategoryParam === value)));
  };
  body.addEventListener('click', (event) => {
    const el = event.target.closest('[data-action]');
    if (event.target === dialog) { dialog.close(); return; }
    if (!el) return;
    const action = el.dataset.action;
    if (action.includes('public-contact#open')) {
      if (el.dataset.publicContactCategoryParam) select(el.dataset.publicContactCategoryParam);
      dialog?.showModal();
    } else if (action.includes('public-contact#close')) {
      dialog?.close();
    } else if (action.includes('public-contact#pick')) {
      const value = el.dataset.publicContactCategoryParam;
      select(category?.value === value ? '' : value);
    }
  });
  document.addEventListener('submit', (event) => {
    event.preventDefault();
    if (notice) { notice.hidden = false; notice.textContent = 'Dziękujemy — odezwiemy się wkrótce. (podgląd)'; }
  });
})();
