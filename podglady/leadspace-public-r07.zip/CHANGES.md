# Runda r07 — Dopasowanie dolnej sekcji do zrzutu OZE online

## Bazuje na
leadspace-public-r06.zip oraz zrzut użytkownika z wersji online.

## Zmiany
### css/additions.css
- Wyłącznie packages-contact: ograniczono szerokość kontenera do 1080 px, odtworzono dwie kolumny z odstępem 65 px, nagłówek 56 px i akapity 16 px oraz przestrzeń sekcji 90 px.
- Reguły na mniejszych ekranach zachowują czytelność i jedną kolumnę na telefonie.
- Treść, tło i czarny przycisk Kontakt z r06 bez zmian. Formularz zachowuje kontrakt public-contact#open.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
brak

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Zweryfikowano brak poziomego przewijania przy 390, 768, 1440 i 2048 px oraz działanie formularza.
- Układ dopasowany do przesłanego obrazu, bez twierdzenia o dokładnej zgodności z niedostępnym CSS serwisu produkcyjnego.
