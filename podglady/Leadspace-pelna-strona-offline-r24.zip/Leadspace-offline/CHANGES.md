# Runda r24 — Uzgodnione poprawki po audycie i krótsze O nas

## Bazuje na
Pełna wersja offline r23.

## Zmiany
### pages/index.html
- Doprecyzowano opis hero: ankieta, kontrola, zakup i pobieranie danych. H1 bez zmian.
- Nagłówek kroku 02 skrócono do Doładuj konto; opis opcji zachowano.
- Podgląd sklepu: Kategoria: Nieruchomości i Podgląd przykładowych leadów zamiast pozornej aktualnej liczby oraz błędnej liczby widocznych wierszy.
### pages/nieruchomosci.html, pages/oze.html, pages/ubezpieczenia.html
- Osoba zainteresowana zamiast Klient w zdaniach kwalifikacyjnych.
- Skrócono tytuł weryfikacji i poprawiono opisy telefonu oraz SMS bez zmiany kryteriów.
### pages/cennik.html
- Dodano informację o przekierowaniu do rejestracji po kliknięciu Wybierz.
### pages/kontakt.html i wspólne etykiety pozostałych stron marketingowych
- Sklep zamiast platforma w etykiecie tematu pomocy i wprowadzeniu.
### pages/o-nas.html
- Usunięto przedostatni blok about-audience (Dla tych, którzy chcą rozmawiać o konkretach) na polecenie użytkownika. Końcowa mini sekcja rejestracji zachowana.
- Dokumenty prawne, ceny, CSS i JS bez zmian. Nie dodano komunikacji o wyłączności.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
- about-audience-grid i about-audience-lead nieużywane po usunięciu sekcji; CSS zachowano.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
### pages/cennik.html
```diff
--- przed
+++ po
@@ -16,6 +16,7 @@
 Doładuj konto.
 Wybierz swój następny kontakt.
 Zacznij od dowolnej kwoty lub wybierz pakiet z dodatkowym bonusem. Środki na koncie wykorzystasz na zakup leadów dostępnych w sklepie.
+Po kliknięciu „Wybierz” przejdziesz do rejestracji.
 Większe doładowanie. Więcej środków na leady.
 W pakietach otrzymujesz dodatkowo 5%, 7% lub 10% wartości wpłaty.
 01
```

### pages/index.html
```diff
--- przed
+++ po
@@ -14,8 +14,8 @@
 Zarejestruj się
 Leady dla Twojej branży. Informacje dla Twojej sprzedaży.
 Lead to dopiero początek.
-Docieramy do zainteresowanych klientów, przeprowadzamy ankietę telefoniczną i kontrolujemy jakość.
-Ty otrzymujesz kontakt opisany danymi istotnymi dla Twojej branży.
+Każdy lead przechodzi ankietę telefoniczną i kontrolę jakości.
+W sklepie wybierasz kontakty dla swojej branży, kupujesz je i pobierasz dane.
 Wybierz swoją branżę
 Zarejestruj się
 Aktualna dostępność w sklepie
@@ -53,7 +53,7 @@
 Kontakt w pierwszej dobie od zgłoszenia ma największą szansę na rozmowę. Sortuj po „Najnowsze”.
 Wszystkie leady
 ● NIERUCHOMOŚCI
-16 leadów dostępnych w pionie
+Kategoria: Nieruchomości
 ⓘ Jak korzystać z katalogu?
 ⌄
 Województwo ⌄
@@ -63,8 +63,7 @@
 Zaawansowane ⌄
 Najnowsze
 Cena
-Pokazano
-1–5 z 16
+Podgląd przykładowych leadów
 Kompaktowy
 Rozszerzony
 Przykładowe leady — podgląd katalogu Lead Space
@@ -173,7 +172,7 @@
 Wybierz kontakty, które pasują do Twojej oferty.
 Zarejestruj się
 02
-Doładuj konto dowolną kwotą lub wybierz pakiet
+Doładuj konto
 Zacznij od dowolnej kwoty albo wybierz pakiet z dodatkowym bonusem.
 Ty decydujesz, ile środków przeznaczysz na zakup leadów.
 Zarejestruj się
```

### pages/kontakt.html
```diff
--- przed
+++ po
@@ -15,7 +15,7 @@
 KONTAKT · LEADSPACE
 Porozmawiajmy
 o Twoich potrzebach.
-Masz pytania dotyczące dostępnych leadów, działania platformy lub współpracy z Leadspace? Napisz do nas. Pomożemy Ci poznać ofertę i rozpocząć korzystanie ze sklepu.
+Masz pytania dotyczące dostępnych leadów, działania sklepu lub współpracy z Leadspace? Napisz do nas. Pomożemy Ci poznać ofertę i rozpocząć korzystanie ze sklepu.
 JESTEŚMY DO TWOJEJ DYSPOZYCJI
 Wybierz wygodny
 sposób kontaktu.
@@ -50,7 +50,7 @@
 Temat wiadomości
 *
 Pytanie dotyczące leadów
-Pomoc w korzystaniu z platformy
+Pomoc w korzystaniu ze sklepu
 Płatności i dokumenty
 Współpraca
 Dane osobowe
```

### pages/nieruchomosci.html
```diff
--- przed
+++ po
@@ -53,13 +53,13 @@
 . Sam kontakt z kampanii to dopiero początek procesu.
 Przejdź do KROKU II
 KROK II · NIERUCHOMOŚCI
-Weryfikacja telefoniczna
-i przeprowadzenie ankiety
+Weryfikacja i ankieta
+telefoniczna
 Każda usługa ma inne wymagania. Sprawdź, jakie warunki spełnia lead i jaki zestaw danych otrzymasz.
 01
 Sprzedaż nieruchomości
 Wymagania, jakie spełnia lead
-Klient deklaruje, że nieruchomość nie znajduje się w ofercie biura nieruchomości lub znajduje się w ofercie biura nieruchomości, ale nie na wyłączność.
+Osoba zainteresowana deklaruje, że nieruchomość nie znajduje się w ofercie biura nieruchomości lub znajduje się w ofercie biura nieruchomości, ale nie na wyłączność.
 Sprawdź dane, jakie otrzymasz — budynki i lokale
 Dom jednorodzinny, Dom w zabudowie bliźniaczej, Mieszkanie, Lokal handlowo-usługowy, Powierzchnia biurowa
 +
@@ -119,7 +119,7 @@
 02
 Zakup nieruchomości
 Wymagania, jakie spełnia lead
-Klient deklaruje zainteresowanie zakupem nieruchomości oraz wskazuje przynajmniej rodzaj poszukiwanej nieruchomości i lokalizację.
+Osoba zainteresowana deklaruje zainteresowanie zakupem nieruchomości oraz wskazuje przynajmniej rodzaj poszukiwanej nieruchomości i lokalizację.
 Sprawdź dane, jakie otrzymasz
 +
 A
@@ -144,7 +144,7 @@
 Wynajem nieruchomości
 Właściciel chce wynająć swoją nieruchomość
 Wymagania, jakie spełnia lead
-Klient deklaruje, że chce wynająć należącą do niego nieruchomość oraz że nieruchomość nie znajduje się w ofercie biura nieruchomości lub znajduje się w ofercie, ale nie na wyłączność.
+Osoba zainteresowana deklaruje, że chce wynająć należącą do niego nieruchomość oraz że nieruchomość nie znajduje się w ofercie biura nieruchomości lub znajduje się w ofercie, ale nie na wyłączność.
 Sprawdź dane, jakie otrzymasz
 +
 A
@@ -177,7 +177,7 @@
 Najem nieruchomości
 Klient szuka nieruchomości do wynajęcia
 Wymagania, jakie spełnia lead
-Klient deklaruje zainteresowanie najmem nieruchomości oraz określa lokalizację i rodzaj poszukiwanej nieruchomości.
+Osoba zainteresowana deklaruje zainteresowanie najmem nieruchomości oraz określa lokalizację i rodzaj poszukiwanej nieruchomości.
 Sprawdź dane, jakie otrzymasz
 +
 A
@@ -207,10 +207,10 @@
 Każdy lead podlega dodatkowej kontroli jakości poprzez jedną z poniższych metod.
 01
 Telefon weryfikacyjny
-Dodatkowy telefon weryfikacyjny.
-02
-Potwierdzenie chęci kontaktu przez SMS
-Potwierdzenie chęci kontaktu.
+Dodatkowa rozmowa sprawdzająca zainteresowanie usługą.
+02
+Potwierdzenie przez SMS
+Osoba zainteresowana potwierdza, że chce kontaktu w sprawie usługi.
 03
 Odsłuch rozmowy konsultanta
 Kontrola rozmowy konsultanta.
```

### pages/o-nas.html
```diff
--- przed
+++ po
@@ -60,12 +60,6 @@
 Pobierz i rozpocznij rozmowę
 Zakupione leady możesz pobrać i wykorzystać we własnym procesie sprzedaży.
 Kupujesz leady, pobierasz dane i prowadzisz dalszą sprzedaż we własnych narzędziach.
-DLA KOGO JEST LEADSPACE?
-Dla tych, którzy
-chcą rozmawiać
-o konkretach.
-Dla firm i specjalistów, którzy chcą docierać do osób zainteresowanych konkretną usługą.
-Pozyskiwanie i weryfikację kontaktów powierzasz nam. Rozmowę, przygotowanie oferty i dalszą sprzedaż prowadzisz po swojej stronie.
 TWÓJ KOLEJNY KROK
 Zacznij od konta w Leadspace.
 Zarejestruj się i uzyskaj dostęp do sklepu z weryfikowanymi leadami.
```

### pages/oze.html
```diff
--- przed
+++ po
@@ -53,16 +53,16 @@
 . Sam kontakt z kampanii to dopiero początek procesu.
 Przejdź do KROKU II
 KROK II · OZE
-Weryfikacja telefoniczna
-i przeprowadzenie ankiety
+Weryfikacja i ankieta
+telefoniczna
 Każda usługa ma inne wymagania. Sprawdź, jakie warunki spełnia lead i jaki zestaw danych otrzymasz.
 01
 Fotowoltaika
 Wymagania, jakie spełnia lead
-Klient deklaruje miesięczne opłaty za energię elektryczną na poziomie minimum 150 zł oraz posiada minimum 25 m² odpowiednio nasłonecznionej powierzchni dachu lub gruntu przeznaczonej pod instalację.
+Osoba zainteresowana deklaruje miesięczne opłaty za energię elektryczną na poziomie minimum 150 zł oraz posiada minimum 25 m² odpowiednio nasłonecznionej powierzchni dachu lub gruntu przeznaczonej pod instalację.
 W przypadku klienta B2C osobą docelową jest właściciel domu jednorodzinnego, współwłaściciel domu jednorodzinnego lub osoba decyzyjna.
 W przypadku klienta B2B osobą docelową jest właściciel, współwłaściciel lub osoba decyzyjna w zakresie budynku lub gruntu.
-Budynek jest oddany do użytku, klient nie planuje modernizacji dachu oraz deklaruje gotowość do odbycia rozmowy lub spotkania w terminie do 30 dni od daty pozyskania leada.
+Budynek jest oddany do użytku, osoba zainteresowana nie planuje modernizacji dachu oraz deklaruje gotowość do odbycia rozmowy lub spotkania w terminie do 30 dni od daty pozyskania leada.
 Akceptowane typy pokrycia dachu
 Dachówka – wyłącznie po potwierdzeniu możliwości jej demontażu, gont bitumiczny, papa, blachodachówka, blacha, płyta obornicka, płyta warstwowa, membrana, wylewka betonowa, styropapa.
 Sprawdź dane, jakie otrzymasz
@@ -95,7 +95,7 @@
 02
 Magazyn energii
 Wymagania, jakie spełnia lead
-Klient posiada instalację fotowoltaiczną oraz deklaruje gotowość do odbycia rozmowy lub spotkania w terminie do 30 dni od daty pozyskania leada.
+Osoba zainteresowana posiada instalację fotowoltaiczną oraz deklaruje gotowość do odbycia rozmowy lub spotkania w terminie do 30 dni od daty pozyskania leada.
 Sprawdź dane, jakie otrzymasz
 +
 A
@@ -121,10 +121,10 @@
 Każdy lead podlega dodatkowej kontroli jakości poprzez jedną z poniższych metod.
 01
 Telefon weryfikacyjny
-Dodatkowy telefon weryfikacyjny.
+Dodatkowa rozmowa sprawdzająca zainteresowanie usługą.
 02
-Potwierdzenie chęci kontaktu przez SMS
-Potwierdzenie chęci kontaktu.
+Potwierdzenie przez SMS
+Osoba zainteresowana potwierdza, że chce kontaktu w sprawie usługi.
 03
 Odsłuch rozmowy konsultanta
 Kontrola rozmowy konsultanta.
```

### pages/ubezpieczenia.html
```diff
--- przed
+++ po
@@ -53,13 +53,13 @@
 . Sam kontakt z kampanii to dopiero początek procesu.
 Przejdź do KROKU II
 KROK II · UBEZPIECZENIA
-Weryfikacja telefoniczna
-i przeprowadzenie ankiety
+Weryfikacja i ankieta
+telefoniczna
 Każda usługa ma inne wymagania. Sprawdź, jakie warunki spełnia lead i jaki zestaw danych otrzymasz.
 01
 Ubezpieczenia komunikacyjne
 Wymagania, jakie spełnia lead
-Klient deklaruje, że polisa kończy się w ciągu najbliższych 60 dni.
+Osoba zainteresowana deklaruje, że polisa kończy się w ciągu najbliższych 60 dni.
 Sprawdź dane, jakie otrzymasz
 +
 A
@@ -135,10 +135,10 @@
 Każdy lead podlega dodatkowej kontroli jakości poprzez jedną z poniższych metod.
 01
 Telefon weryfikacyjny
-Dodatkowy telefon weryfikacyjny.
+Dodatkowa rozmowa sprawdzająca zainteresowanie usługą.
 02
-Potwierdzenie chęci kontaktu przez SMS
-Potwierdzenie chęci kontaktu.
+Potwierdzenie przez SMS
+Osoba zainteresowana potwierdza, że chce kontaktu w sprawie usługi.
 03
 Odsłuch rozmowy konsultanta
 Kontrola rozmowy konsultanta.
```

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium: wszystkie 9 stron przy 390, 768, 1440 px — jeden H1, kotwice, nowe treści, usunięta sekcja O nas, brak poziomego scrolla i błędów JS.
- Oba dokumenty prawne są identyczne bajtowo ze stanem przed tą rundą.
- Przekierowanie /accounts/signup/ zachowane; backend zakupów, rejestracji i wysyłki nie był testowany.
