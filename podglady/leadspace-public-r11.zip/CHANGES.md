# Runda r11 — Sekcja Pakietów na stronie głównej

## Bazuje na
leadspace-public-r10.zip

## Zmiany
### pages/index.html
- Dodano home-packages po branżach, przed rozpoczęciem współpracy.
- Krótka informacja o dowolnym doładowaniu i trzy karty pakietów z kwotami netto, mniejszą kwotą brutto, bonusem netto i sumą netto.
- Istniejący czarny przycisk Zobacz pakiety prowadzi do cennik.html.
### css/additions.css
- Dodano responsywny układ sekcji: błękitne tło, kremowe karty, etykiety bonusów.

## Nowe klasy CSS
- home-packages, home-packages-heading, home-packages-grid, home-package-card, home-package-top, home-package-bonus, home-package-price, home-package-gross, home-packages-note (css/additions.css).

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Dodano nagłówek „Doładuj konto. Skorzystaj z bonusu.”
- Opis: „Wybierz pakiet i otrzymaj dodatkowe środki na zakup leadów. Możesz też zacząć od dowolnej kwoty i kupować nawet pojedyncze kontakty.”
- Pakiet 2 500: 2 500 zł netto, 3 075 zł brutto, bonus 125 zł netto, suma 2 625 zł netto; bonus 5%.
- Pakiet 5 000: 5 000 zł netto, 6 150 zł brutto, bonus 350 zł netto, suma 5 350 zł netto; bonus 7%.
- Pakiet 10 000: 10 000 zł netto, 12 300 zł brutto, bonus 1 000 zł netto, suma 11 000 zł netto; bonus 10%.
- Przycisk: „Zobacz pakiety”.
- Nota: „Wybierasz wartość doładowania, nie liczbę leadów. Cenę każdego kontaktu sprawdzisz w sklepie przed zakupem.”

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768, 1440 px: układ, kolejność sekcji, jeden H1, link do Pakietów, brak poziomego przewijania.
