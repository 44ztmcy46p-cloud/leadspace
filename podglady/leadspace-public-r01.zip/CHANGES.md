# Runda r01 — Nowa treść i układ graficzny strony „O nas”

## Bazuje na
leadspace-public-2026-10-13.zip

## Zmiany
### pages/o-nas.html
- Zastąpiono artykuł sekcjami: otwarcie z panelem wartości, karty misji, oferta sklepu, odbiorcy i wyróżniony kontakt.
- Treść dotyczy zakupu i pobierania leadów, bez obietnic CRM. Nie wprowadzono niepotwierdzonych statystyk ani referencji.
- Kontakt: mailto z istniejącym adresem, link do kontakt.html i istniejący przycisk public-contact#open.
- Zachowano wszystkie istniejące ID i ich atrybuty, head, APP comments, nagłówek, stopkę oraz formularz.
### css/additions.css
- Dodano wyłącznie reguły about-* z responsywnymi siatkami, kartami i pastelowymi powierzchniami.
- Bez modyfikacji innych stron, CSS generowanego ani JS podglądu.

## Nowe klasy CSS
- about-hero, about-hero-grid, about-intro, about-hero-copy — otwarcie strony.
- about-story, about-story-caption, about-story-card, about-story-bottom — panel wartości leada.
- about-section, about-section-heading, about-mission-grid, about-mission-card, about-number — sekcje i karty misji.
- about-blue, about-offer-grid, about-copy, about-shop-steps, about-scope — oferta sklepu.
- about-audience-grid, about-audience-lead — odbiorcy.
- about-contact, about-contact-grid, about-contact-card, about-email, about-contact-link — kontakt.
- Wszystkie klasy w css/additions.css.

## Usunięte / nieużywane klasy
- ls-section, ls-legal, ls-eyebrow, ls-h, ls-lede nie są już używane w treści tej strony; pozostają w CSS dla pozostałych dokumentów.

## Nowe tokeny kolorów
brak — użyto istniejących tokenów.

## Zmiany tekstów
Pełna treść poprzedniego main została zastąpiona poniższą treścią. Bez zmian treści poza main.

### Nowa treść main
O NAS · LEADSPACE

Wspieramy

proces sprzedaży.

Ty rozwijasz swoją ofertę.

My pomagamy Ci dotrzeć do zainteresowanych klientów.

Pozyskujemy kontakty, weryfikujemy je telefonicznie i opisujemy danymi istotnymi dla danej usługi. Ty wybierasz leady w sklepie, kupujesz je i pobierasz dane do dalszej pracy.

Porozmawiajmy o współpracy

NIE TYLKO KONTAKT.

INFORMACJE, Z KTÓRYMI MOŻESZ DZIAŁAĆ.

01

Zainteresowanie

Kontakt do osoby zainteresowanej konkretną usługą.

02

Potrzeby

Odpowiedzi z ankiety telefonicznej właściwej dla danej usługi.

03

Weryfikacja

Dodatkowa kontrola jakości przed udostępnieniem leada.

Poznaj klienta, zanim rozpoczniesz rozmowę.

NASZA MISJA

Dobry kontakt.

Lepszy punkt wyjścia.

Wartość leada to coś więcej niż numer telefonu. To informacje, które pomagają przygotować się do rozmowy i dopasować ofertę.

01

Ułatwiać

Ułatwiamy naszym klientom pozyskiwanie wartościowych kontaktów. Dostarczamy wyselekcjonowane
        leady, które przeszły ankietę telefoniczną i kontrolę jakości oraz spełniają wymagania
        określone dla danej usługi.

02

Wspierać

Wspieramy przygotowanie do pierwszej rozmowy. Wraz z kontaktem przekazujemy odpowiedzi
        z ankiety, dzięki którym poznasz potrzeby potencjalnego klienta i łatwiej dopasujesz
        swoją ofertę. Zakupione leady możesz pobrać i wykorzystać we własnym procesie sprzedaży.

03

Współpracować

Chcemy być partnerem w pozyskiwaniu klientów. Rozmawiamy o potrzebach Twojej firmy
        i pomagamy dobrać odpowiedni rodzaj leadów. Wspólnie dążymy do tego, aby przekazywane
        kontakty odpowiadały Twojej ofercie i celom sprzedażowym.

NASZA OFERTA

Wybierasz leady.

Pobierasz dane.

Robisz kolejny krok.

Dostarczamy zweryfikowane leady sprzedażowe dla nieruchomości, OZE i ubezpieczeń. Rozwijamy ofertę o kolejne branże, zachowując ten sam nacisk na weryfikację kontaktu i jakość przekazywanych danych.

Wybierz swoją branżę

01

Sprawdź zakres danych

Na podstronie branży poznasz wymagania, jakie spełnia lead, oraz informacje, które otrzymasz.

02

Wybierz i kup

W sklepie LeadSpace wybierasz dostępne kontakty odpowiednie dla Twojej oferty.

03

Pobierz i rozpocznij rozmowę

Zakupione leady możesz pobrać i wykorzystać we własnym procesie sprzedaży.

Dalszą obsługę prowadzisz we własnych narzędziach. LeadSpace nie dostarcza systemu CRM ani rozwiązania do zarządzania procesem sprzedaży.

DLA KOGO JEST LEADSPACE?

Dla tych, którzy

chcą rozmawiać

o konkretach.

Dla firm i specjalistów, którzy chcą docierać do osób zainteresowanych konkretną usługą.

Potrzebujesz wartościowych kontaktów i informacji pozwalających przygotować się do rozmowy? Właśnie z myślą o takiej pracy powstał LeadSpace.

Wiemy, że przekazanie leada nie kończy procesu pozyskania klienta. Dla Ciebie to początek dalszej pracy: rozmowy, dopasowania oferty i budowania relacji. Naszą rolą jest ułatwić ten pierwszy krok, dostarczając zweryfikowany kontakt wraz z danymi z ankiety.

POROZMAWIAJMY

Twoja branża.

Twoje potrzeby.

Nasza rozmowa.

Chcesz sprawdzić, jakie leady będą odpowiednie dla Twojej firmy? Skontaktuj się z nami — porozmawiamy o Twojej branży i potrzebach.

NAPISZ DO NAS

kontakt.leadspace@dgm.pl

Wolisz zacząć od formularza? Zostaw wiadomość i opisz, jakich kontaktów szukasz.

Porozmawiajmy o współpracy

Zobacz stronę kontaktową →

## Nowe ikony (Lucide) i obrazy
brak — kompozycja typograficzna i karty CSS.

## Do decyzji / pytania
- Meta description w aplikacji nadal mówi o historii zespołu. Propozycja do wdrożenia: „Poznaj LeadSpace — sklep z weryfikowanymi leadami. Wybierz kontakty dla swojej branży, kup je i pobierz dane do dalszej pracy.” Head eksportu pozostawiono bez zmian.
- Chromium 390, 768 i 1440 px: brak poziomego scrolla, jeden H1, trzy karty misji, otwieranie i zamykanie kontaktu, brak błędów JS.
- Zweryfikowano zachowanie ID i atrybutów aplikacji oraz brak zmian w pozostałych plikach.
- Wysyłkę formularza należy sprawdzić w docelowej aplikacji Django; nie była testowana w statycznym podglądzie.
