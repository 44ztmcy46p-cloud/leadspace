# Runda r01 — Treść „O nas” dla sklepu z weryfikowanymi leadami

## Bazuje na
leadspace-public-2026-10-13.zip

## Zmiany
### pages/o-nas.html
- Zastąpiono treść artykułu opisem misji, oferty sklepu i odbiorców. Usunięto historię poprzedniego projektu i obietnice narzędzi CRM.
- Dodano kontakt e-mail oraz CTA otwierające istniejący dialog. Zachowano jeden styl przycisku concept-button i kontrakt public-contact#open.
- Bez zmian CSS, nagłówka, stopki, formularza, atrybutów aplikacji i komentarzy APP.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
Cały artykuł strony „O nas” zastąpiono poniższą treścią. Nagłówek sekcji „O nas” pozostaje bez zmian.

### Przed zmianą
O nas

Lead Space

Blisko 20 lat doświadczenia w sprzedaży. Teraz wykorzystujemy je dla branży nieruchomości,
        OZE i ubezpieczeń.

Budujemy platformę, na której można znaleźć i wybrać zweryfikowane leady odpowiadające
        konkretnej branży, regionowi oraz potrzebom sprzedażowym.

Naszym celem jest skrócenie drogi pomiędzy osobą lub firmą, która zgłosiła konkretną
        potrzebę, a specjalistą, który może przygotować dla niej odpowiednią ofertę.

Skąd pomysł na Lead Space?

Pomysł na Lead Space pojawił się w odpowiedzi na zapytania firm, które szukały sposobu
        na dotarcie do osób realnie zainteresowanych ich usługami — a nie do przypadkowych
        kontaktów z bazy.

Po zrealizowaniu pierwszych takich kampanii zauważyliśmy, że na rynku brakuje miejsca,
        w którym agent nieruchomości, instalator OZE czy doradca ubezpieczeniowy może wybrać
        zweryfikowany kontakt do osoby, która sama zgłosiła potrzebę i zgodziła się na rozmowę.
        Postanowiliśmy takie miejsce zbudować.

Tak powstał Lead Space — miejsce tworzone z myślą o firmach, które chcą skuteczniej
        pozyskiwać klientów i rozwijać swoją działalność.

Sprzedaż znamy od środka

Doświadczenie zespołu stojącego za Lead Space sięga 2007 roku. Zaczynaliśmy od
        sprzedaży telefonicznej usług największych marek telekomunikacyjnych i medialnych, takich
        jak Netia, Orange oraz CANAL+. W kolejnych latach rozwijaliśmy się w kierunku generowania
        leadów i wspierania sprzedaży firm z wielu branż.

Blisko 20 lat pracy z różnymi produktami, klientami i modelami sprzedaży nauczyło nas
        przede wszystkim szukania rozwiązań. Nie działamy według jednego sztywnego schematu.
        Analizujemy potrzeby partnera, specyfikę jego rynku oraz sposób, w jaki klienci podejmują
        decyzje, a następnie szukamy najskuteczniejszej drogi dotarcia do właściwych osób.

To właśnie umiejętności łączenia doświadczenia sprzedażowego, danych i praktycznego
        podejścia do pozyskiwania klientów stanowią fundament Lead Space.

### Po zmianie
O nas

Wspieramy proces sprzedaży

Pomagamy firmom docierać do osób zainteresowanych ich ofertą. Pozyskujemy kontakty,
        weryfikujemy je telefonicznie i opisujemy danymi istotnymi dla danej usługi.
        Ty wybierasz leady w sklepie, kupujesz je i pobierasz dane do dalszej pracy.

Nasza misja

Ułatwiać

Ułatwiamy naszym klientom pozyskiwanie wartościowych kontaktów. Dostarczamy wyselekcjonowane
        leady, które przeszły ankietę telefoniczną i kontrolę jakości oraz spełniają wymagania
        określone dla danej usługi.

Wspierać

Wspieramy przygotowanie do pierwszej rozmowy. Wraz z kontaktem przekazujemy odpowiedzi
        z ankiety, dzięki którym poznasz potrzeby potencjalnego klienta i łatwiej dopasujesz
        swoją ofertę. Zakupione leady możesz pobrać i wykorzystać we własnym procesie sprzedaży.

Współpracować

Chcemy być partnerem w pozyskiwaniu klientów. Rozmawiamy o potrzebach Twojej firmy
        i pomagamy dobrać odpowiedni rodzaj leadów. Wspólnie dążymy do tego, aby przekazywane
        kontakty odpowiadały Twojej ofercie i celom sprzedażowym.

Nasza oferta

Dostarczamy zweryfikowane leady sprzedażowe dla nieruchomości, OZE i ubezpieczeń.
        Rozwijamy ofertę o kolejne branże, zachowując ten sam nacisk na weryfikację kontaktu
        i jakość przekazywanych danych.

Zanim lead trafi do sklepu, przechodzi proces pozyskania, telefonicznej weryfikacji
        i ankiety oraz dodatkowej kontroli jakości. Na podstronie danej branży sprawdzisz
        wymagania, jakie spełnia lead, i zakres danych, które otrzymasz.

W sklepie LeadSpace możesz wybrać i kupić dostępne leady, a następnie pobrać ich dane.
        Dalszą obsługę kontaktów prowadzisz we własnych narzędziach — LeadSpace nie dostarcza
        systemu CRM ani rozwiązania do zarządzania procesem sprzedaży.

Dla kogo stworzyliśmy LeadSpace?

LeadSpace powstał z myślą o firmach i specjalistach, którzy chcą docierać do osób
        zainteresowanych konkretną usługą. To miejsce dla tych, którzy potrzebują wartościowych
        kontaktów i informacji pozwalających przygotować się do rozmowy.

Wiemy, że przekazanie leada nie kończy procesu pozyskania klienta. Dla Ciebie to początek
        dalszej pracy: rozmowy, dopasowania oferty i budowania relacji. Naszą rolą jest ułatwić
        ten pierwszy krok, dostarczając zweryfikowany kontakt wraz z danymi z ankiety.

Porozmawiajmy o współpracy

Chcesz sprawdzić, jakie leady będą odpowiednie dla Twojej firmy? Skontaktuj się z nami
        — porozmawiamy o Twojej branży i potrzebach.

kontakt.leadspace@dgm.pl

Porozmawiajmy o współpracy

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Propozycja opisu SEO w aplikacji: „Poznaj LeadSpace — sklep z weryfikowanymi leadami. Wybierz kontakty dla swojej branży, kup je i pobierz dane do dalszej pracy.” Obecnego head nie zmieniono zgodnie z kontraktem eksportu.
- Chromium: sprawdzono 390, 768 i 1440 px — brak przewijania poziomego; CTA otwiera dialog, a przycisk zamknięcia go zamyka. Brak błędów JS.
- Kontrola statyczna potwierdziła jeden H1, unikalne ID i zachowanie plików poza treścią artykułu. Formularz wysyłający dane wymaga testu w aplikacji Django.
