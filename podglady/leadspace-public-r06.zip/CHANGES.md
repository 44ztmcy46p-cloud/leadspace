# Runda r06 — Dolna sekcja z OZE na stronie Pakietów

## Bazuje na
leadspace-public-r05.zip oraz pages/oze.html z paczki 2026-10-13.

## Zmiany
### pages/cennik.html
- Zastąpiono packages-contact dolną sekcją oze-difference z dostarczonego eksportu. Zachowano klasy, tekst i tło. Wyłącznie tekst przycisku zmieniono na Kontakt; istniejący public-contact#open otwiera formularz.
- Technicznie zachowano ID packages-contact i packages-contact-title dla sekcji i nagłówka.
- CSS bez zmian.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
- packages-contact, packages-contact-row nadal nieużywane w HTML; pozostają w CSS.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Wykorzystano treść z OZE: „WIĘCEJ NIŻ KONTAKT Z REKLAMY”, „Najpierw weryfikacja. Potem Twój kolejny krok.” oraz oba akapity o dodatkowej ankiecie i kontroli jakości.
- Przycisk ze źródła: „Porozmawiajmy o współpracy” → „Kontakt”.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Dostęp online do https://www.leadspace.pl/oze/ blokuje proxy (403). Wykorzystano OZE z dostarczonej paczki; nie potwierdzono zgodności ze zmienioną wersją produkcyjną.
- Chromium 390 i 1440 px: brak poziomego scrolla, formularz otwiera się i zamyka.
