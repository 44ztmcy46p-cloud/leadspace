# Runda r12 — Dowolne doładowanie obok pakietów na stronie głównej

## Bazuje na
leadspace-public-r11.zip

## Zmiany
### pages/index.html
- Dodano pierwszą kartę Doładuj konto — Dowolna kwota. Wyraźnie opisuje możliwość zakupu pojedynczych leadów bez pakietu.
- Przenumerowano karty na 01–04, zachowano dane pakietów i przycisk Zobacz pakiety.
### css/additions.css
- Cztery karty na desktopie, dwie poniżej 1100 px, jedna na telefonie.

## Nowe klasy CSS
- home-package-flexible, home-package-flexible-note — opis dowolnego doładowania (css/additions.css).

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Nagłówek: „Doładuj konto. Skorzystaj z bonusu.” → „Zacznij od dowolnej kwoty. Lub wybierz pakiet z bonusem.”
- Dodano: „Elastyczny start”, „Doładuj konto”, „Dowolna kwota”, „Kwota brutto: netto + 23% VAT”, „Sposób zakupu: Pojedyncze leady”, „Do wykorzystania: Twoja wpłata netto”.
- Opis karty: „Nie musisz wybierać pakietu. Doładuj konto wybraną kwotą i kupuj leady zgodnie z potrzebami.”

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768 i 1440 px: cztery karty, właściwa kolejność sekcji, link do Pakietów i brak przewijania poziomego.
