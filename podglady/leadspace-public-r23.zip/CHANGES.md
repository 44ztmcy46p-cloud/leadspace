# Runda r23 — Ujednolicenie i skrócenie copywritingu całego serwisu

## Bazuje na
leadspace-public-r22.zip (pełny stan offline 14.10.2026).

## Zmiany
### pages/*.html
- Marka Leadspace w treści marketingowej, wspólnej nawigacji, modalach, stopce i opisach SEO. Logo Lead Space w ilustracyjnym katalogu zachowano zgodnie z dostarczonym zrzutem.
- Wspólny górny CTA Zarejestruj się; modal Kontakt i submit Wyślij wiadomość.
- Odrębne nagłówki stron branżowych i krótsze wprowadzenia; nazwy kampanii i kontroli w naturalnej polszczyźnie.
- Końcowe sekcje kontaktu mają nowe zaproszenie zamiast powtórzenia nagłówka procesu.
- Skrócono karty misji i opis odbiorców O nas, opisano pracę we własnych narzędziach.
- Ujednolicono opis doładowania, zaktualizowano SEO Pakietów i O nas.
- Pakiety: dodano krótką informację o standardowym 30-dniowym okresie wykorzystania zgodnie z istniejącym regulaminem i wyjątkiem dla kategorii/projektu.
- Nie dodano treści dotyczących wyłączności. Zakresy kwalifikacji i listy otrzymywanych danych pozostały poza korektami językowymi.
- Treści main regulaminu i polityki prywatności zachowano dokładnie; ujednolicono tylko wspólne otoczenie stron (nagłówek, stopkę, modal, pisownię marki w head).
- Bez zmian CSS, skryptów, tras, formularzy, atrybutów aplikacji i kwot pakietów; CTA górne kierują do używanego dotąd /accounts/signup/.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
Poniższy wykaz porównuje teksty całych dokumentów (w tym SEO i modalów), z pominięciem formatowania HTML.

### pages/cennik.html
```diff
--- cennik.html przed
+++ cennik.html po
@@ -1,4 +1,4 @@
-Cennik leadów — LeadSpace
+Pakiety doładowania — Leadspace
 Przejdź do treści
 leadspace
 Strona główna
@@ -11,7 +11,7 @@
 Kontakt
 O nas
 Zaloguj się
-Umów spotkanie
+Zarejestruj się
 PAKIETY · LEADSPACE
 Doładuj konto.
 Wybierz swój następny kontakt.
@@ -89,25 +89,29 @@
 Od rejestracji do pierwszego leada.
 01
 Zarejestruj się
-Kliknij „Zarejestruj się” i utwórz konto w LeadSpace.
+Kliknij „Zarejestruj się” i utwórz konto w Leadspace.
 Zarejestruj się
 02
 Doładuj konto
-Wybierz dowolną kwotę lub pakiet z dodatkowym bonusem.
+Doładuj konto dowolną kwotą lub wybierz pakiet z dodatkowym bonusem.
 03
 Kup i pobierz leady
 Wybierz interesujące kontakty w sklepie i pobierz zakupione dane.
-WIĘCEJ NIŻ KONTAKT Z REKLAMY
-Najpierw weryfikacja.
-Potem Twój kolejny krok.
-Podstawowy lead z kampanii reklamowej to początek procesu. W LeadSpace dokładamy ankietę telefoniczną i kontrolę jakości, zanim udostępnimy kontakt w sklepie.
-Dzięki temu wiesz, jakiej usługi szuka klient i czy spełnia warunki wymagane dla danego produktu. Nasz proces służy temu, aby do sklepu trafiały wyłącznie leady spełniające wymagania jakościowe.
+KORZYSTANIE Z DANYCH
+Jak długo mogę korzystać z leada?
+Standardowy okres wykorzystania leada wynosi 30 dni kalendarzowych, chyba że dla danej kategorii lub projektu wskazano inny okres. Sprawdź informacje przy leadzie i zasady opisane w
+regulaminie
+.
+MASZ PYTANIA?
+Porozmawiajmy
+o leadach dla Twojej firmy.
+Chcesz poznać zakres danych lub zasady zakupu? Napisz do nas — pomożemy Ci wybrać odpowiednie kontakty.
 Kontakt
 leadspace
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -115,7 +119,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -132,4 +136,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/index.html
```diff
--- index.html przed
+++ index.html po
@@ -1,4 +1,4 @@
-LeadSpace — zweryfikowane leady dla Twojej branży
+Leadspace — zweryfikowane leady dla Twojej branży
 Przejdź do treści
 leadspace
 Strona główna
@@ -128,7 +128,7 @@
 Slot — ∞∞∞
 +
 Dodaj
-Widok katalogu leadów w sklepie LeadSpace
+Widok katalogu leadów w sklepie Leadspace
 OD PIERWSZEGO KONTAKTU DO ZWERYFIKOWANEGO LEADA
 Najpierw weryfikacja.
 Potem Twój kolejny krok.
@@ -173,7 +173,7 @@
 Wybierz kontakty, które pasują do Twojej oferty.
 Zarejestruj się
 02
-Doładuj konto lub kup pakiet
+Doładuj konto dowolną kwotą lub wybierz pakiet
 Zacznij od dowolnej kwoty albo wybierz pakiet z dodatkowym bonusem.
 Ty decydujesz, ile środków przeznaczysz na zakup leadów.
 Zarejestruj się
@@ -182,17 +182,16 @@
 Wybierz interesujące kontakty, kup je i pobierz dane.
 Przygotuj ofertę i rozpocznij rozmowę z potencjalnym klientem.
 Zarejestruj się
-WIĘCEJ NIŻ KONTAKT Z REKLAMY
-Najpierw weryfikacja.
-Potem Twój kolejny krok.
-Podstawowy lead z kampanii reklamowej to początek procesu. W LeadSpace dokładamy ankietę telefoniczną i kontrolę jakości, zanim udostępnimy kontakt w sklepie.
-Dzięki temu wiesz, jakiej usługi szuka klient i czy spełnia warunki wymagane dla danego produktu. Nasz proces służy temu, aby do sklepu trafiały wyłącznie leady spełniające wymagania jakościowe.
+MASZ PYTANIA?
+Porozmawiajmy
+o leadach dla Twojej firmy.
+Chcesz poznać zakres danych lub zasady zakupu? Napisz do nas — pomożemy Ci wybrać odpowiednie kontakty.
 Kontakt
 leadspace
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -200,7 +199,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -217,4 +216,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/kontakt.html
```diff
--- kontakt.html przed
+++ kontakt.html po
@@ -1,4 +1,4 @@
-Kontakt — LeadSpace, zweryfikowane leady
+Kontakt — Leadspace, zweryfikowane leady
 Przejdź do treści
 leadspace
 Strona główna
@@ -68,7 +68,7 @@
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -76,7 +76,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -93,4 +93,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/nieruchomosci.html
```diff
--- nieruchomosci.html przed
+++ nieruchomosci.html po
@@ -1,4 +1,4 @@
-Jakość leadów nieruchomości — LeadSpace
+Jakość leadów nieruchomości — Leadspace
 Przejdź do treści
 leadspace
 Strona główna
@@ -11,12 +11,12 @@
 Kontakt
 O nas
 Zaloguj się
-Umów spotkanie
+Zarejestruj się
 ← Strona główna
 NIERUCHOMOŚCI · JAKOŚĆ LEADÓW
-Kontakt to dopiero początek.
-Liczy się to, co o nim wiesz.
-Pozyskujemy leady na Twój produkt z sześciu kanałów. Zanim kontakt trafi do sklepu, weryfikujemy go telefonicznie, przeprowadzamy ankietę i sprawdzamy jakość pracy konsultanta. Otrzymujesz kontakt opisany danymi istotnymi dla Twojej usługi.
+Zweryfikowane leady
+dla branży nieruchomości.
+Każdy lead przechodzi ankietę telefoniczną i kontrolę jakości. Sprawdź wymagania dla poszczególnych usług oraz dane, które otrzymasz po zakupie.
 Sprawdź, jakie dane otrzymasz
 Cztery etapy. Jeden zweryfikowany lead.
 01
@@ -32,15 +32,15 @@
 Lead dostępny w sklepie
 Dopiero wtedy możesz go kupić.
 KROK I · NIERUCHOMOŚCI
-Pozyskanie leadów
-na produkt klienta
+Pozyskanie kontaktów
+zainteresowanych Twoją ofertą
 Docieramy do potencjalnych klientów poprzez sześć kanałów pozyskania leadów.
 01
 Kampania mailingowa
 02
-Kampania Instagram
-03
-Kampania Facebook
+Kampania na Instagramie
+03
+Kampania na Facebooku
 04
 Kampania Google Ads
 05
@@ -169,7 +169,7 @@
 Rodzaj nieruchomości
 Rynek nieruchomości
 Powierzchnia nieruchomości
-Ilość pokoi
+Liczba pokoi
 Dodatkowe udogodnienia
 Dodatkowe informacje
 Termin skorzystania z usługi
@@ -195,18 +195,18 @@
 Rodzaj nieruchomości
 Rynek nieruchomości
 Powierzchnia nieruchomości
-Ilość pokoi
+Liczba pokoi
 Dodatkowe udogodnienia
 Dodatkowe informacje
 Termin skorzystania z usługi
 Wiele lokalizacji, konkretne potrzeby.
 Formularz przewiduje wielokrotny wybór miejscowości, a następnie określenie m.in. rodzaju nieruchomości, powierzchni i liczby pokoi.
 KROK III · NIERUCHOMOŚCI
-Kontrola poprawności
-pracy konsultanta
+Kontrola jakości rozmowy
+i zebranych danych
 Każdy lead podlega dodatkowej kontroli jakości poprzez jedną z poniższych metod.
 01
-Verification call
+Telefon weryfikacyjny
 Dodatkowy telefon weryfikacyjny.
 02
 Potwierdzenie chęci kontaktu przez SMS
@@ -214,17 +214,16 @@
 03
 Odsłuch rozmowy konsultanta
 Kontrola rozmowy konsultanta.
-Dopiero po przejściu procesu pozyskania, przeprowadzeniu ankiety telefonicznej oraz weryfikacji i kontroli jakości lead trafia do sklepu i może zostać zakupiony.
-WIĘCEJ NIŻ KONTAKT Z REKLAMY
-Najpierw weryfikacja.
-Potem Twój kolejny krok.
-Podstawowy lead z kampanii reklamowej to początek procesu. W LeadSpace dokładamy ankietę telefoniczną i kontrolę jakości, zanim udostępnimy kontakt w sklepie.
-Dzięki temu wiesz, jakiej usługi szuka klient, jakie ma potrzeby i kiedy planuje z niej skorzystać. Nasz proces służy temu, aby do sklepu trafiały wyłącznie leady spełniające wymagania jakościowe.
-Porozmawiajmy o współpracy
+Po ankiecie telefonicznej i kontroli jakości lead trafia do sklepu.
+MASZ PYTANIA?
+Porozmawiajmy
+o leadach dla Twojej firmy.
+Chcesz poznać zakres danych lub zasady zakupu? Napisz do nas — pomożemy Ci wybrać odpowiednie kontakty.
+Kontakt
 leadspace
 ®
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -232,7 +231,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -249,4 +248,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/o-nas.html
```diff
--- o-nas.html przed
+++ o-nas.html po
@@ -1,4 +1,4 @@
-O nas — LeadSpace, zweryfikowane leady
+O nas — Leadspace, zweryfikowane leady
 Przejdź do treści
 leadspace
 Strona główna
@@ -37,13 +37,13 @@
 Wartość leada to coś więcej niż numer telefonu. To informacje, które pomagają przygotować się do rozmowy i dopasować ofertę.
 01
 Ułatwiać
-Ułatwiamy naszym klientom pozyskiwanie wartościowych kontaktów. Dostarczamy wyselekcjonowane leady, które przeszły ankietę telefoniczną i kontrolę jakości oraz spełniają wymagania określone dla danej usługi.
+Ułatwiamy dotarcie do osób zainteresowanych konkretną usługą. Dostarczamy leady po ankiecie telefonicznej i kontroli jakości, zgodne z wymaganiami danej kategorii.
 02
 Wspierać
-Wspieramy przygotowanie do pierwszej rozmowy. Wraz z kontaktem przekazujemy odpowiedzi z ankiety, dzięki którym poznasz potrzeby potencjalnego klienta i łatwiej dopasujesz swoją ofertę. Zakupione leady możesz pobrać i wykorzystać we własnym procesie sprzedaży.
+Pomagamy przygotować się do rozmowy. Odpowiedzi z ankiety pozwalają poznać potrzeby potencjalnego klienta i dopasować ofertę.
 03
 Współpracować
-Chcemy być partnerem w pozyskiwaniu klientów. Rozmawiamy o potrzebach Twojej firmy i pomagamy dobrać odpowiedni rodzaj leadów. Wspólnie dążymy do tego, aby przekazywane kontakty odpowiadały Twojej ofercie i celom sprzedażowym.
+Rozmawiamy o potrzebach Twojej firmy i pomagamy dobrać leady odpowiednie dla Twojej oferty.
 NASZA OFERTA
 Wybierasz leady.
 Pobierasz dane.
@@ -55,18 +55,17 @@
 Na podstronie branży poznasz wymagania, jakie spełnia lead, oraz informacje, które otrzymasz.
 02
 Wybierz i kup
-W sklepie LeadSpace wybierasz dostępne kontakty odpowiednie dla Twojej oferty.
+W sklepie Leadspace wybierasz dostępne kontakty odpowiednie dla Twojej oferty.
 03
 Pobierz i rozpocznij rozmowę
 Zakupione leady możesz pobrać i wykorzystać we własnym procesie sprzedaży.
-Dalszą obsługę prowadzisz we własnych narzędziach. LeadSpace nie dostarcza systemu CRM ani rozwiązania do zarządzania procesem sprzedaży.
+Kupujesz leady, pobierasz dane i prowadzisz dalszą sprzedaż we własnych narzędziach.
 DLA KOGO JEST LEADSPACE?
 Dla tych, którzy
 chcą rozmawiać
 o konkretach.
 Dla firm i specjalistów, którzy chcą docierać do osób zainteresowanych konkretną usługą.
-Potrzebujesz wartościowych kontaktów i informacji pozwalających przygotować się do rozmowy? Właśnie z myślą o takiej pracy powstał LeadSpace.
-Wiemy, że przekazanie leada nie kończy procesu pozyskania klienta. Dla Ciebie to początek dalszej pracy: rozmowy, dopasowania oferty i budowania relacji. Naszą rolą jest ułatwić ten pierwszy krok, dostarczając zweryfikowany kontakt wraz z danymi z ankiety.
+Pozyskiwanie i weryfikację kontaktów powierzasz nam. Rozmowę, przygotowanie oferty i dalszą sprzedaż prowadzisz po swojej stronie.
 TWÓJ KOLEJNY KROK
 Zacznij od konta w Leadspace.
 Zarejestruj się i uzyskaj dostęp do sklepu z weryfikowanymi leadami.
@@ -75,7 +74,7 @@
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -83,7 +82,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -100,4 +99,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/oze.html
```diff
--- oze.html przed
+++ oze.html po
@@ -1,4 +1,4 @@
-Jakość leadów OZE — LeadSpace
+Jakość leadów OZE — Leadspace
 Przejdź do treści
 leadspace
 Strona główna
@@ -11,12 +11,12 @@
 Kontakt
 O nas
 Zaloguj się
-Umów spotkanie
+Zarejestruj się
 ← Strona główna
 OZE · JAKOŚĆ LEADÓW
-Kontakt to dopiero początek.
-Liczy się to, co o nim wiesz.
-Pozyskujemy leady na Twój produkt z sześciu kanałów. Zanim kontakt trafi do sklepu, weryfikujemy go telefonicznie, przeprowadzamy ankietę i sprawdzamy jakość pracy konsultanta. Otrzymujesz kontakt opisany danymi istotnymi dla Twojej usługi.
+Leady dla fotowoltaiki
+i magazynów energii.
+Każdy lead przechodzi ankietę telefoniczną i kontrolę jakości. Sprawdź wymagania dla poszczególnych usług oraz dane, które otrzymasz po zakupie.
 Sprawdź, jakie dane otrzymasz
 Cztery etapy. Jeden zweryfikowany lead.
 01
@@ -32,15 +32,15 @@
 Lead dostępny w sklepie
 Dopiero wtedy możesz go kupić.
 KROK I · OZE
-Pozyskanie leadów
-na produkt klienta
+Pozyskanie kontaktów
+zainteresowanych Twoją ofertą
 Docieramy do potencjalnych klientów poprzez sześć kanałów pozyskania leadów.
 01
 Kampania mailingowa
 02
-Kampania Instagram
+Kampania na Instagramie
 03
-Kampania Facebook
+Kampania na Facebooku
 04
 Kampania Google Ads
 05
@@ -116,11 +116,11 @@
 Aktualny system rozliczeń
 Ustalenie właściciela licznika
 KROK III · OZE
-Kontrola poprawności
-pracy konsultanta
+Kontrola jakości rozmowy
+i zebranych danych
 Każdy lead podlega dodatkowej kontroli jakości poprzez jedną z poniższych metod.
 01
-Verification call
+Telefon weryfikacyjny
 Dodatkowy telefon weryfikacyjny.
 02
 Potwierdzenie chęci kontaktu przez SMS
@@ -128,18 +128,17 @@
 03
 Odsłuch rozmowy konsultanta
 Kontrola rozmowy konsultanta.
-Dopiero po przejściu procesu pozyskania, przeprowadzeniu ankiety telefonicznej oraz weryfikacji i kontroli jakości lead trafia do sklepu i może zostać zakupiony.
-WIĘCEJ NIŻ KONTAKT Z REKLAMY
-Najpierw weryfikacja.
-Potem Twój kolejny krok.
-Podstawowy lead z kampanii reklamowej to początek procesu. W LeadSpace dokładamy ankietę telefoniczną i kontrolę jakości, zanim udostępnimy kontakt w sklepie.
-Dzięki temu wiesz, jakiej usługi szuka klient i czy spełnia warunki wymagane dla danego produktu. Nasz proces służy temu, aby do sklepu trafiały wyłącznie leady spełniające wymagania jakościowe.
-Porozmawiajmy o współpracy
+Po ankiecie telefonicznej i kontroli jakości lead trafia do sklepu.
+MASZ PYTANIA?
+Porozmawiajmy
+o leadach dla Twojej firmy.
+Chcesz poznać zakres danych lub zasady zakupu? Napisz do nas — pomożemy Ci wybrać odpowiednie kontakty.
+Kontakt
 leadspace
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -147,7 +146,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -164,4 +163,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/polityka-prywatnosci.html
```diff
--- polityka-prywatnosci.html przed
+++ polityka-prywatnosci.html po
@@ -1,4 +1,4 @@
-Polityka prywatności — LeadSpace
+Polityka prywatności — Leadspace
 Przejdź do treści
 leadspace
 Strona główna
@@ -11,7 +11,7 @@
 Kontakt
 O nas
 Zaloguj się
-Umów spotkanie
+Zarejestruj się
 Dokument prawny
 Polityka prywatności platformy LEADSPACE.PL
 Wersja obowiązująca od: 28.08.2026 r.
@@ -222,7 +222,7 @@
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -230,7 +230,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -247,4 +247,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/regulamin.html
```diff
--- regulamin.html przed
+++ regulamin.html po
@@ -1,4 +1,4 @@
-Regulamin platformy LeadSpace
+Regulamin platformy Leadspace
 Przejdź do treści
 leadspace
 Strona główna
@@ -11,7 +11,7 @@
 Kontakt
 O nas
 Zaloguj się
-Umów spotkanie
+Zarejestruj się
 Dokument prawny
 Regulamin platformy LEADSPACE.PL
 Wersja obowiązująca od: 11.09.2026 r.
@@ -214,7 +214,7 @@
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -222,7 +222,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -239,4 +239,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

### pages/ubezpieczenia.html
```diff
--- ubezpieczenia.html przed
+++ ubezpieczenia.html po
@@ -1,4 +1,4 @@
-Jakość leadów ubezpieczeniowych — LeadSpace
+Jakość leadów ubezpieczeniowych — Leadspace
 Przejdź do treści
 leadspace
 Strona główna
@@ -11,12 +11,12 @@
 Kontakt
 O nas
 Zaloguj się
-Umów spotkanie
+Zarejestruj się
 ← Strona główna
 UBEZPIECZENIA · JAKOŚĆ LEADÓW
-Kontakt to dopiero początek.
-Liczy się to, co o nim wiesz.
-Pozyskujemy leady na Twój produkt z sześciu kanałów. Zanim kontakt trafi do sklepu, weryfikujemy go telefonicznie, przeprowadzamy ankietę i sprawdzamy jakość pracy konsultanta. Otrzymujesz kontakt opisany danymi istotnymi dla Twojej usługi.
+Zweryfikowane kontakty
+dla doradców ubezpieczeniowych.
+Każdy lead przechodzi ankietę telefoniczną i kontrolę jakości. Sprawdź wymagania dla poszczególnych usług oraz dane, które otrzymasz po zakupie.
 Sprawdź, jakie dane otrzymasz
 Cztery etapy. Jeden zweryfikowany lead.
 01
@@ -32,15 +32,15 @@
 Lead dostępny w sklepie
 Dopiero wtedy możesz go kupić.
 KROK I · UBEZPIECZENIA
-Pozyskanie leadów
-na produkt klienta
+Pozyskanie kontaktów
+zainteresowanych Twoją ofertą
 Docieramy do potencjalnych klientów poprzez sześć kanałów pozyskania leadów.
 01
 Kampania mailingowa
 02
-Kampania Instagram
+Kampania na Instagramie
 03
-Kampania Facebook
+Kampania na Facebooku
 04
 Kampania Google Ads
 05
@@ -57,9 +57,9 @@
 i przeprowadzenie ankiety
 Każda usługa ma inne wymagania. Sprawdź, jakie warunki spełnia lead i jaki zestaw danych otrzymasz.
 01
-Komunikacyjne
+Ubezpieczenia komunikacyjne
 Wymagania, jakie spełnia lead
-Deklarowany termin zakończenia polisy do 60 dni
+Klient deklaruje, że polisa kończy się w ciągu najbliższych 60 dni.
 Sprawdź dane, jakie otrzymasz
 +
 A
@@ -86,9 +86,9 @@
 Rocznik pojazdu (opcjonalne)
 Wiek klienta (opcjonalne)
 02
-Życie
+Ubezpieczenia na życie
 Wymagania, jakie spełnia lead
-Pełnoletni do 65 roku życia
+Osoba pełnoletnia w wieku do 65 lat
 Sprawdź dane, jakie otrzymasz
 +
 A
@@ -108,7 +108,7 @@
 Posiadanie ubezpieczenia na życie
 Obecny ubezpieczyciel (opcjonalne)
 03
-Majątkowe
+Ubezpieczenia majątkowe
 Wymagania, jakie spełnia lead
 Właściciel lub współwłaściciel nieruchomości
 Sprawdź dane, jakie otrzymasz
@@ -130,11 +130,11 @@
 Obecny ubezpieczyciel (opcjonalne)
 Typ nieruchomości
 KROK III · UBEZPIECZENIA
-Kontrola poprawności
-pracy konsultanta
+Kontrola jakości rozmowy
+i zebranych danych
 Każdy lead podlega dodatkowej kontroli jakości poprzez jedną z poniższych metod.
 01
-Verification call
+Telefon weryfikacyjny
 Dodatkowy telefon weryfikacyjny.
 02
 Potwierdzenie chęci kontaktu przez SMS
@@ -142,18 +142,17 @@
 03
 Odsłuch rozmowy konsultanta
 Kontrola rozmowy konsultanta.
-Dopiero po przejściu procesu pozyskania, przeprowadzeniu ankiety telefonicznej oraz weryfikacji i kontroli jakości lead trafia do sklepu i może zostać zakupiony.
-WIĘCEJ NIŻ KONTAKT Z REKLAMY
-Najpierw weryfikacja.
-Potem Twój kolejny krok.
-Podstawowy lead z kampanii reklamowej to początek procesu. W LeadSpace dokładamy ankietę telefoniczną i kontrolę jakości, zanim udostępnimy kontakt w sklepie.
-Dzięki temu wiesz, jakiej usługi szuka klient i czy spełnia warunki wymagane dla danego ubezpieczenia. Nasz proces służy temu, aby do sklepu trafiały wyłącznie leady spełniające wymagania jakościowe.
-Porozmawiajmy o współpracy
+Po ankiecie telefonicznej i kontroli jakości lead trafia do sklepu.
+MASZ PYTANIA?
+Porozmawiajmy
+o leadach dla Twojej firmy.
+Chcesz poznać zakres danych lub zasady zakupu? Napisz do nas — pomożemy Ci wybrać odpowiednie kontakty.
+Kontakt
 leadspace
 ®
 Jak weryfikujemy leady
 kontakt.leadspace@dgm.pl
-© 2026 LeadSpace
+© 2026 Leadspace
 Regulamin
 Polityka prywatności
 Pakiety
@@ -161,7 +160,7 @@
 O nas
 Operator platformy: DGM Maciej Małek
 Płatności obsługuje Przelewy24
-Umów spotkanie
+Kontakt
 Porozmawiajmy o leadach dla Twojej firmy.
 Imię i nazwisko
 Adres e-mail
@@ -178,4 +177,4 @@
 Wyrażam zgodę na przetwarzanie moich danych osobowych w celu odpowiedzi na zgłoszenie. Więcej w
 Polityce prywatności
 .
-Przygotuj zgłoszenie
+Wyślij wiadomość
```

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium 390, 768, 1440 px: wszystkie 9 stron, jeden H1, brak poziomego przewijania, linki kotwic, wspólna rejestracja i tekst modala, działający podgląd dialogu.
- Programista wprowadza meta title/description w aplikacji zgodnie z uaktualnionym eksportem.
- Polityki prawnej i zasad kwalifikacji nie modyfikowano. Pytanie o wyłączność nie zostało dodane.
- Rejestracja, zakup i rzeczywista wysyłka formularzy wymagają aplikacji; nie były testowane w statycznym podglądzie.
