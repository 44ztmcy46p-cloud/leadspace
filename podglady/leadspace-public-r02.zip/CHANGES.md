# Runda r02 — Pakiety doładowania konta zamiast Cennika

## Bazuje na
Runda r01 (O nas) oraz leadspace-public-2026-10-13.zip.

## Zmiany
### pages/cennik.html
- Nowa treść Pakietów: dowolna kwota i zakup pojedynczych leadów; 2 500 zł + 125 zł (5%) = 2 625 zł; 5 000 zł + 350 zł (7%) = 5 350 zł; 10 000 zł + 1 000 zł (10%) = 11 000 zł.
- Cztery karty z numeracją 01–04, kwotą wpłaty, bonusem, dostępnymi środkami i linkiem Wybierz.
- Wybierz wskazuje /accounts/signup/. Ten adres przyjęto roboczo: eksport zawiera jedynie /accounts/login/, nie zawiera strony rejestracji. Przed wdrożeniem zastąpić href rzeczywistą trasą/url reverse rejestracji, jeśli jest inna. Nie testowano rejestracji ani przekazywania wyboru pakietu do backendu.
- Dodano trzy etapy zakupu i kontakt mailowy oraz CTA istniejącego dialogu.
- Nie wprowadzono cen leadów, VAT, ważności środków, kodów promocji ani metod płatności ze zdjęcia referencyjnego. Wymagają osobnych ustaleń.
- Zachowano plik cennik.html, aby nie naruszać struktury eksportu. W aplikacji nazwę/URL /pakiety/ może ustalić zespół.
### pages/*.html (wszystkie 9 dokumentów)
- Etykieta Cennik w menu i stopce zmieniona na Pakiety, href pozostaje cennik.html. Treść regulaminu i polityki prywatności nie została zmieniona.
### css/additions.css
- Dopisano reguły packages-*; poprzednie reguły O nas i pozostałe style zachowano.
- Układ czterech kart na desktopie, dwóch poniżej 1100 px, jednej poniżej 768 px.

## Nowe klasy CSS
- packages-hero, packages-intro, packages-banner — wprowadzenie.
- packages-options, packages-grid, packages-card, packages-card-top, packages-number, packages-badge, packages-amount, packages-flexible, packages-description, packages-breakdown, packages-total, packages-note — opcje doładowania.
- packages-how, packages-section-heading, packages-steps — instrukcja zakupu.
- packages-contact, packages-contact-row — kontakt.
- Wszystkie w css/additions.css; CTA wykorzystują istniejący concept-button.

## Usunięte / nieużywane klasy
- Dawne klasy ls-legal na stronie cennika nie są już używane w jej main. CSS pozostaje dla innych stron.

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Menu i stopka wszystkich stron: Cennik → Pakiety.
- Główna treść cennik.html: dawny artykuł z zasadami ceny leada zastąpiono poniższym tekstem.

PAKIETY · LEADSPACE

Doładuj konto.

Wybierz swój następny kontakt.

Zacznij od dowolnej kwoty lub wybierz pakiet z dodatkowym bonusem. Środki na koncie wykorzystasz na zakup leadów dostępnych w sklepie.

Większe doładowanie. Więcej środków na leady.

W pakietach otrzymujesz dodatkowo 5%, 7% lub 10% wartości wpłaty.

01

Elastyczny start

Doładuj konto

Dowolna kwota

Zacznij od pojedynczych leadów. Doładuj konto wybraną kwotą i kupuj kontakty zgodnie z potrzebami.

Doładowanie

Dowolna kwota

Sposób zakupu

Pojedyncze leady

Do wykorzystania

Twoja wpłata

Kupujesz tyle leadów, ile potrzebujesz.

Wybierz

02

Bonus 5%

Pakiet 2 500

2 500 zł

Dodatkowe środki do wykorzystania na zakup leadów.

Doładowanie

2 500 zł

Dodatkowy bonus

125 zł · +5%

Do wykorzystania

2 625 zł

Łączna wartość doładowania z bonusem.

Wybierz

03

Bonus 7%

Pakiet 5 000

5 000 zł

Więcej środków na kolejne kontakty dla Twojej firmy.

Doładowanie

5 000 zł

Dodatkowy bonus

350 zł · +7%

Do wykorzystania

5 350 zł

Łączna wartość doładowania z bonusem.

Wybierz

04

Bonus 10%

Pakiet 10 000

10 000 zł

Najwyższy bonus spośród dostępnych pakietów.

Doładowanie

10 000 zł

Dodatkowy bonus

1 000 zł · +10%

Do wykorzystania

11 000 zł

Łączna wartość doładowania z bonusem.

Wybierz

Pakiety określają środki do wykorzystania, a nie liczbę leadów. Aktualną cenę każdego leada sprawdzisz w sklepie przed zakupem.

PROSTY START

Od rejestracji do pierwszego leada.

01

Zarejestruj się

Kliknij „Wybierz” i utwórz konto w LeadSpace.

02

Doładuj konto

Wybierz dowolną kwotę lub pakiet z dodatkowym bonusem.

03

Kup i pobierz leady

Wybierz interesujące kontakty w sklepie i pobierz zakupione dane.

MASZ PYTANIA?

Porozmawiajmy o Twoich potrzebach.

Pomożemy Ci poznać dostępne leady i możliwości współpracy.

kontakt.leadspace@dgm.pl

Porozmawiajmy o współpracy

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Rejestracja: /accounts/signup/ wymaga potwierdzenia w aplikacji. Próba odczytu serwisu przez proxy zwróciła 403, więc nie potwierdzono trasy produkcyjnej.
- Meta title proponowane: „Pakiety doładowania — LeadSpace”. Meta description proponowane: „Doładuj konto dowolną kwotą lub wybierz pakiet LeadSpace z bonusem 5%, 7% lub 10%. Kupuj leady i pobieraj dane do dalszej pracy.” Head pozostawiono zgodnie z kontraktem eksportu.
- Potwierdzić zasady finansowe po stronie aplikacji: kwoty, naliczanie bonusów, ewentualne podatki i ograniczenia promocji.
- Chromium 390, 768, 1440 px: cztery karty, poprawne sumy, brak przewijania poziomego, kontakt otwiera i zamyka dialog, brak błędów JS.
- Matematycznie sprawdzono bonusy i sumy. Zachowanie linków do rejestracji sprawdzono statycznie; backend nie był testowany.
