# Runda r21 — Pisownia Leadspace w końcowej sekcji O nas

## Bazuje na
leadspace-public-r20.zip

## Zmiany
### pages/o-nas.html
- Zmieniono wyłącznie pisownię marki w nagłówku ostatniej sekcji.

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- „Zacznij od konta w LeadSpace.” → „Zacznij od konta w Leadspace.”

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
brak
