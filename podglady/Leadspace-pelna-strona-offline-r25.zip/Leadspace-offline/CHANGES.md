# Runda r25 — Przywrócenie sekcji Dla kogo jest Leadspace

## Bazuje na
Leadspace-pelna-strona-offline-r24.zip

## Zmiany
### pages/o-nas.html
- Przywrócono about-audience z r23, przed końcową sekcją rejestracji.
- Wszystkie pozostałe fragmenty i pliki pozostają bez zmian.

## Nowe klasy CSS
brak — użyto zachowanych about-audience-grid i about-audience-lead.

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
brak

## Zmiany tekstów
- Przywrócono „DLA KOGO JEST LEADSPACE?”, „Dla tych, którzy chcą rozmawiać o konkretach.” oraz dwa akapity wskazane przez użytkownika.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
brak
