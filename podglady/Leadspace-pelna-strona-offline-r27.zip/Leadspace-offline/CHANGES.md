# Runda r27 — Sticky navbar, usunięcie ® i kompaktowy proces

## Bazuje na
Leadspace-pelna-strona-offline-r26.zip

## Zmiany
### pages/*.html
- Usunięto znak ® przy logo w stopce wszystkich dziewięciu stron, bez zmiany linków i danych firmy.
### css/additions.css
- v3-header: position sticky, top 0, z-index 40 i nieprzezroczyste tło z istniejących tokenów. Bez nowego JavaScriptu.
- Scroll-padding-top dopasowany do wysokości menu: 113 px desktop, 180 px dla zawijanego menu, 210 px telefon.
- Kontener procesu homepage: max-width 1160 px. Minimalna wysokość kart zmniejszona z 290 do 240 px (210 px telefon).

## Nowe klasy CSS
brak

## Usunięte / nieużywane klasy
brak

## Nowe tokeny kolorów
- --color-pub-header-offset: 113px / 180px / 210px — zmienna wymiaru (nie kolor), w additions.css; prefiks pozostaje zgodny z kontraktem eksportu.

## Zmiany tekstów
- Usunięto ® przy logo w stopce. Pozostałe teksty bez zmian.

## Nowe ikony (Lucide) i obrazy
brak

## Do decyzji / pytania
- Chromium: wszystkie dziewięć stron przy 390, 768 i 1440 px — menu pozostaje na top 0 po scrollu, brak ® w stopce, brak poziomego przewijania.
- Homepage: kotwica branż nie jest zasłonięta, a dialog kontaktowy działa nad menu.
- Treść main obu dokumentów prawnych pozostaje identyczna.
